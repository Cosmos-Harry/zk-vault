/* tslint:disable */
/* eslint-disable */

export class CountryProofResult {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly proof_bytes: Uint8Array;
  readonly country_code: string;
  readonly country_name: string;
  readonly public_input: string;
  readonly error: string | undefined;
  readonly success: boolean;
  readonly proof_hex: string;
}

export class EmailProofResult {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly commitment: string;
  readonly domain_hash: string;
  readonly proof_bytes: Uint8Array;
  readonly dkim_verified: boolean;
  readonly error: string | undefined;
  readonly domain: string;
  readonly success: boolean;
  readonly proof_hex: string;
}

/**
 * Get list of supported countries as JSON
 */
export function get_supported_countries(): string;

/**
 * Get version info
 */
export function get_version(): string;

/**
 * Hash a string to a field element (for ZK circuits)
 */
export function hash_to_field(input: string): string;

export function init(): void;

/**
 * Initialize the ZK prover for country proofs.
 * This performs trusted setup - call once at startup.
 * Returns true if successful.
 */
export function init_country_prover(): boolean;

/**
 * Initialize the ZK prover for email domain proofs.
 * This performs trusted setup - call once at startup.
 * Returns true if successful.
 */
export function init_email_prover(): boolean;

/**
 * Check if email prover is initialized
 */
export function is_email_prover_ready(): boolean;

/**
 * Check if country prover is initialized
 */
export function is_prover_ready(): boolean;

/**
 * Simpler version: prove country from country code (for IP geolocation).
 * This still generates a real ZK proof but uses predefined bounds.
 */
export function prove_country(country_code: string): CountryProofResult;

/**
 * Generate a REAL ZK proof of country from coordinates.
 * 
 * This creates a Groth16 proof that proves you're in a specific country
 * without revealing your exact coordinates.
 */
export function prove_country_from_coords(lat: number, lng: number): CountryProofResult;

/**
 * Generate a REAL ZK proof of email domain ownership.
 * 
 * This creates a Groth16 proof that you own an email at the specified domain
 * without revealing the actual email address.
 */
export function prove_email_domain(domain: string, dkim_signature: string, auth_results: string): EmailProofResult;

/**
 * Verify a country proof
 */
export function verify_country_proof(proof_hex: string, public_input_hex: string): boolean;

/**
 * Verify an email domain proof
 */
export function verify_email_proof(proof_hex: string, domain_hash_hex: string, commitment_hex: string): boolean;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_countryproofresult_free: (a: number, b: number) => void;
  readonly __wbg_emailproofresult_free: (a: number, b: number) => void;
  readonly countryproofresult_country_code: (a: number) => [number, number];
  readonly countryproofresult_country_name: (a: number) => [number, number];
  readonly countryproofresult_error: (a: number) => [number, number];
  readonly countryproofresult_proof_bytes: (a: number) => [number, number];
  readonly countryproofresult_proof_hex: (a: number) => [number, number];
  readonly countryproofresult_public_input: (a: number) => [number, number];
  readonly countryproofresult_success: (a: number) => number;
  readonly emailproofresult_commitment: (a: number) => [number, number];
  readonly emailproofresult_dkim_verified: (a: number) => number;
  readonly emailproofresult_domain: (a: number) => [number, number];
  readonly emailproofresult_domain_hash: (a: number) => [number, number];
  readonly emailproofresult_error: (a: number) => [number, number];
  readonly emailproofresult_proof_bytes: (a: number) => [number, number];
  readonly emailproofresult_proof_hex: (a: number) => [number, number];
  readonly get_supported_countries: () => [number, number];
  readonly get_version: () => [number, number];
  readonly hash_to_field: (a: number, b: number) => [number, number];
  readonly init_country_prover: () => number;
  readonly init_email_prover: () => number;
  readonly is_email_prover_ready: () => number;
  readonly is_prover_ready: () => number;
  readonly prove_country: (a: number, b: number) => number;
  readonly prove_country_from_coords: (a: number, b: number) => number;
  readonly prove_email_domain: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
  readonly verify_country_proof: (a: number, b: number, c: number, d: number) => number;
  readonly verify_email_proof: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
  readonly init: () => void;
  readonly emailproofresult_success: (a: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_externrefs: WebAssembly.Table;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
